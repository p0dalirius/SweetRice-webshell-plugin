<?php
/**
 * WebShell config.
 *
 * @package SweetRice
 * @Plugin WebShell
 * @since 1.4.2
 */
?>